# TaobaoHistorySearch
仿淘宝历史搜索记录

1、整个搜索过程词条维持在10条

2、短词条可以在三行全部显示完，多出的行数隐藏，长词条默认只显示两行，多出的部分隐藏

3、点击更多箭头展示全部词条，长按出现删除某个词条弹框，点击清理按钮可以清除所有历史记录

![实现效果](https://upload-images.jianshu.io/upload_images/7717043-39471e79e75056f2.gif?imageMogr2/auto-orient/strip)

